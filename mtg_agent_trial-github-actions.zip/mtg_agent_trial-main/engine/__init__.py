"""Game-engine integration boundary."""
